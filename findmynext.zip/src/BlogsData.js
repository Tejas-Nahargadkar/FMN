import blogs01 from './components/assets/blogs01.svg'
import blogs02 from './components/assets/blogs02.svg'
import blogs03 from './components/assets/blogs03.svg'



const BlogsData = [
    {
        image:blogs01,
        Heading:'Interview Advice',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
    {
        image:blogs02,
        Heading:'How to use FMN',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
    {
        image:blogs03,
        Heading:'Career Advice',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
    {
        image:blogs03,
        Heading:'How to use FMN',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
    {
        image:blogs02,
        Heading:'Career Advice',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
    {
        image:blogs01,
        Heading:'Interview Advice',
        content:'Lorem Ipsum is simply dummy textof the printing and typesetting industry. Lorem Ipsum has bee the industry standard',
    },
]

export default BlogsData;