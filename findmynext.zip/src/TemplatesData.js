import template01 from './components/assets/template01.svg'
import template02 from './components/assets/template02.png'
import template03 from './components/assets/template03.svg'
import template04 from './components/assets/template04.svg'

const Templates = [
    
        {
            image:template01,
        },
        {
            image:template02,
        },
        {
            image:template03,
        },
        {
            image:template04,
        },
        {
            image:template01,
        },
        {
            image:template02,
        },
        {
            image:template03,
        },
        {
            image:template04,
        },
        {
            image:template01,
        },
        {
            image:template02,
        },
        {
            image:template03,
        },
        {
            image:template04,
        },
]

export default Templates;