import kpit from './components/assets/kpit.svg'
import wipro from './components/assets/wipro.png'
import micron from './components/assets/micron.png'
import mphasis from './components/assets/mphasis.png'
const CompanyData = [
        {
            image:kpit,
            link:'/kpit'
        },
        {
            image:wipro,
            link:'/wipro',
        },
        {
            image:micron,
            link:'/wipro',
        },
        {
            image:mphasis,
            link:'/wipro',
        },
        {
            image:kpit,
            link:'/wipro',
        },
        {
            image:wipro,
            link:'/wipro',
        },
        {
            image:micron,
            link:'/wipro',
        },
        {
            image:mphasis,
            link:'/wipro',
        },
        {
            image:kpit,
            link:'/wipro',
        },

]
export default CompanyData