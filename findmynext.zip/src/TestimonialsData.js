import T1 from './components/assets/Ellipse 8.svg'


const Testimonial = [
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
{
    image:T1,
    Name:'Akash Singh',
    Review:' Lorem ipsum dolor sit amet consectetur adipisicing elit.Adipisci ipsam, omnis natus dolor porro aut tempore essedelectus quisquam quas commodi odio veniam cum deserunt vitaerepellendus. Placeat in illum dolores asperiores expedita eaquod odio praesentium aperiam rem, non quidem error! Officiismodi ipsam'
},
]
export default Testimonial