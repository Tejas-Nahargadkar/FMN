const TopCompaniesHiring =[
        {
            title:'MNC',
            link:'/MNC'
        },
        {
            title:'UNICORN',
            link:'/MNC'
        },
        {
            title:'B2C',
            link:'/MNC'
        },
        {
            title:'STARTUP',
            link:'/MNC'
        },
        {
            title:'MNC',
            link:'/MNC'
        },
        {
            title:'UNICORN',
            link:'/UNICORN'
        },
        {
            title:'B2C',
            link:'/B2C'
        },
        {
            title:'STARTUP',
            link:'/STARTUP'
        },
]

export default TopCompaniesHiring