 const sector =[
   'It Industries','It Technologies','KPO','BPO'
]
 const industries = [
    'It Industries','It Technologies','KPO','BPO'
]

 const CompanyType =[
    'It Industries','It Technologies','KPO','BPO'
]

export {sector,industries,CompanyType}